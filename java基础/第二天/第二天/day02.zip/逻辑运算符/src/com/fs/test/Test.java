package com.fs.test;
/**
 * 1. & һ����� ȫ��Ϊ��
 * 2. | һ��Ϊ�� ȫ��Ϊ��
 * 3. ^ ��ͬΪ�� ����Ϊ��
 * 
 * @author li
 *
 */


public class Test {

	public static void main(String[] args) {
		// & 
		boolean a = true;
		boolean b = false;
		boolean c = true;
		boolean d = false;
		
		System.out.println("a & b" + (a & b)); // false  true & false 
		System.out.println("a & c" + (a & c)); // true   true & true
		System.out.println("b & d" + (b & d)); // false  false & false
		System.out.println("b & c" + (b & c)); // false
		System.out.println("a & b" + (a & b)); // false
		
		// | 
		System.out.println("a | b" + (a | b));  // true
		System.out.println("a | c" + (a | c));  // true
		System.out.println("c | d" + (a | b));  // true
		System.out.println("b | d" + (a | b));  // false
		
		System.out.println("a ^ b" + (a ^ b)); // true
		System.out.println("a ^ c" + (a ^ c)); // false
		
	
	
	}
	
	

}
