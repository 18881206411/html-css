package com.fs.test;

public class Test1 {
	public boolean x() {
		System.out.println("x......");
		return true;
	}
	
	public boolean y() {
		System.out.println("y....");
		return false;
	}
	
	public boolean z() {
		// TODO Auto-generated method stub
		System.out.println("z......");
		return true;
	}
	
	public void fMethod() {
		boolean l = x() && y() && z();
//        boolean f = x() || y() || z();
		System.out.println(l);
	}
}
