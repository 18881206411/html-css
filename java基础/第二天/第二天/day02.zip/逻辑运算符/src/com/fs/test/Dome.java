package com.fs.test;

public class Dome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// && || !
		
		boolean a = true;
		boolean b = false;
		System.out.println(a && b); //  false 
		System.out.println(a || b); //  true 
		int x = 10;
		int y = 20;
		// true  &&  true       &&   false  &&  false
//		if(x < y && (y = 5) < x && (x = 5)>y && (y = 60) < x ) {
//			System.out.println("x = " + x + ", y = " + y);
//		}else {
//			System.out.println("x = " + x + ", y = " + y);
//		}
		
//		if(x < y & (y = 5) < x & (x = 5)>y & (y = 60) < x ) {
//			System.out.println("x = " + x + ", y = " + y);
//		}else {
//			System.out.println("x = " + x + ", y = " + y);
//		}
		
		if(x < y || (y = 5) < x || (x = 5)>y || (y = 60) < x ) {
			System.out.println("x = " + x + ", y = " + y);
		}else {
			System.out.println("x = " + x + ", y = " + y);
		}
		
		System.out.println(!(x < y)); // false
		
		System.out.println(!((x = 5)>y)); //  true
		
		new Test1().fMethod();
	}

}
