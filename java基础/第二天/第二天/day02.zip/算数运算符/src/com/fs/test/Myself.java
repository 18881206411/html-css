package com.fs.test;
/**
 * ++ -- 
 * @author li
 *
 */
public class Myself {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 10;
		/*
		 * ++ �ں�: ��ʹ����++ 
		 * ++ ��ǰ: ��++��ʹ��
		 */
		System.out.println(a ++ ); //10
		System.out.println(a ++ ); //11
		System.out.println(++ a ); //13
		System.out.println(a ++ ); // 13 
		System.out.println(++ a ); // 15 
		/*
		 *  --  
		 */
		System.out.println("+++++++++++++++++++++++");
		System.out.println(a -- ); //15 14
		System.out.println(a -- ); //14 13
		System.out.println(-- a ); //12 12
		System.out.println(a -- ); // 12 11 
		System.out.println(-- a ); // 10 10 
		
		for (int i = 0; i < args.length; i++) {
			
		}
		int i = 10;
		while (true) {
			i ++;
			
		}
	}

}
