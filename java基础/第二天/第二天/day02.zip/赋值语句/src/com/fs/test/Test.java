package com.fs.test;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 10; // =
//		a = a + 20; // 30
		a += 20; // 30
		a -= 20; // 10
		a *= 20; // 200
		a /= 20; // 10
	}

}
