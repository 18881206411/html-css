package com.fs.test;

public class ArrayTest {
	public void eat(int[] a) {
		a[0] = 100;
		
		System.out.println(a);
	}
	
	public int[] age() {
//		int[] a = new int[1];
//		return a;
		return new int[1];
		
	}

	public static void main(String[] args) {
		ArrayTest at = new ArrayTest();
		int[] b = new int[3];
		// ��̬��ʼ��
		b[0] = 1;
		b[1] = 2;
		b[2] = 3;
		at.eat(b);
		System.out.println(b);
		System.out.println(b[0]);
		
		int[] i = at.age();
		
		// ��̬��ʼ��
		String[] s = new String[] {"1","2","3"};
		System.out.println(s[0]);
		System.out.println(s[1]);
		System.out.println(s[2]);
	}
}
