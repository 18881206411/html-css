package com.fs.test;

import java.util.Arrays;

public class ForArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array = new int[] {1,6,3,4,5,2};
		// a[0] ... a[5]
		for(int i = 0;i < array.length;i++) {
//			System.out.println(array[i]);
		}
		
		for (int element : array) {
			System.out.println(element);
		}
		
		System.out.println("+++++++++++++++");
		Arrays.sort(array);
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i]);
		}
	}

}
