package com.fs.test;

public class Test {

	public static void main(String[] args) {
		// == >  < >= <= !=
		int a = 10;
		int b = 10;
		System.out.println(a == b); // true
		Integer x = 100;
		Integer y = 100;
		System.out.println(x == y);
		
		Test t = new Test();
		Test t1 = new Test();
		System.out.println(t == t1);
		
		Integer x1 = new Integer(100);
		Integer y1 = new Integer(100);
		System.out.println(x1);
		System.out.println(y1);
		
		System.out.println(x1 == y1);
	}

}
