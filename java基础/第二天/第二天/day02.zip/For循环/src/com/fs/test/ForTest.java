package com.fs.test;
public class ForTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		for(;;) {
//			System.out.println("����һ����ѭ��");
//		}
//		1*1
//		2*1 2*2
//		3*1 3*2 3*3
//		....
		// ��ӡ���žų˷���
//		int a = 0;
//		for (int i = 1; i < 10; i++) {
//			for (int j = 1; j <= i; j++) {
//				a = i * j;
//				System.out.print(i + "*" + j + "=" + a + "\t");
//			}
//			System.out.println();
//		}
		
		int[] a = {1,2,3,4,5};
		for(int i : a) {
			System.out.println(i);
		}
		
		
	}

}
