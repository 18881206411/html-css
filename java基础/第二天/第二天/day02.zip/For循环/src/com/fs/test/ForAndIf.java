package com.fs.test;

public class ForAndIf {

	public static void main(String[] args) {
//		int a = 0;
//		out: // ��ǩ
//		for (int i = 1; i < 10; i++) {
//			for (int j = 1; j <= i; j++) {
//				if(i == 4) {
//					break out;
//				}
//				a = i * j;
//				System.out.print(i + "*" + j + "=" + a + "\t");
//			}
//			System.out.println();
//		}
		/**
		 * break : ������ǰѭ��
		 * continue: ������һ��ѭ��,������һ��ѭ��
		 */
		int a = 0;
		out: // ��ǩ
		for (int i = 1; i < 10; i++) {
			for (int j = 1; j <= i; j++) {
				if(i == 4) {
					continue out;
				}
				a = i * j;
				System.out.print(i + "*" + j + "=" + a + "\t");
			}
			System.out.println();
		}

	}

}
